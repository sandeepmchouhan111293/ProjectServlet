package com.cg.asset.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class DbUtil {

	
	static Connection connection;
	static InitialContext context;
	static DataSource source;

	public static Connection getConnection() throws NamingException, SQLException 
	{
	        context = new InitialContext();
	        source = (DataSource) context.lookup("java:/myDS");
	        connection = source.getConnection();

	    return connection;
	}
}
