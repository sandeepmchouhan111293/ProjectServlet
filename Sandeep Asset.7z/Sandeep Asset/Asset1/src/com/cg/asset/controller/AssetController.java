package com.cg.asset.controller;

import java.io.IOException;




import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



import com.cg.asset.dto.Asset;
import com.cg.asset.dto.Employee;
import com.cg.asset.dto.User;
import com.cg.asset.exception.UserException;
import com.cg.asset.service.IUserService;
import com.cg.asset.service.UserService;
import com.cg.asset.util.DbUtil;

//****************************************************************************************************
//Servlet Url
@WebServlet("*.mvc")
public class AssetController extends HttpServlet 
{
	  private static final long serialVersionUID = 1L;
	  
//Declaring Instance variables
//*****************************************************************************************************
			IUserService service;
			User user;
			RequestDispatcher rd;
			Asset object;
			int id1;
			String id;
//*****************************************************************************************************
//Init Method to Initialize Instance Variables	
			@Override 
			public void init() throws ServletException 
			{ 
				service=new UserService();
				object=new Asset();
				
			}
//*******************************************************************************************************
//Servlet Methods DOGET and DOPOST

protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
{ 
//**********************************************************************************************************
//Taking servlet path like form.mvc

	String action=request.getServletPath();
	System.out.println(action);

//**********************************************************************************************************
	
	switch (action) 
	{
//***********************************************1)Form.mvc method****************************************************************
 	case "/form.mvc":
			
		System.out.println("Started...!!!!!");
		
		id=request.getParameter("userid");
		
		String pass=request.getParameter("password");
			   
		try 
		{
			int compare=service.compare(id,pass);
			System.out.println("compare" +compare);
			if(compare==1)		//If Compare equal to 1 it will go to Admin page
			{
				try
				{
					List<Asset> emps=service.getAll();					//getall method to get all pending request Ids  
					request.getSession().setAttribute("emplist", emps);    //add list into SESSION
				}
				catch(UserException ex)
				{
					//If there is an error an error it will get stored in session
					request.getSession().setAttribute("error", ex.getMessage());
				}
					rd = request.getRequestDispatcher("Admin.jsp"); //Forwarding request to Admin.jsp
					rd.forward(request, response); //Forwarding request and response objects
			}
			else if(compare==2) //If Compare equal to 2 it will go to Manager page
			{
					rd = request.getRequestDispatcher("Manager.jsp");
					rd.forward(request, response);
			}
		} 
		catch (UserException e) 
		{
			e.printStackTrace();
		}
		break;	
//***********************************************2) assetform.mvc method****************************************************************
	case "/assetform.mvc":
		
		System.out.println("assetform");
				
		object.setAssetname(request.getParameter("assetname"));
		object.setAssetdes(request.getParameter("assetdes"));
		object.setQuantity(request.getParameter("quantity"));
		object.setStatus("pending");
				 
		
		try 
		{
			id1=service.add(object);
			object.setAssetid(id1);
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
			request.getSession().setAttribute("ast", object);
			rd = request.getRequestDispatcher("Manager.jsp");
			rd.forward(request, response);
		break;	
//***********************************************3) assetDetails.mvc method****************************************************************				
case"/assetDetails.mvc":
				
		id=request.getParameter("id");
		System.out.println(id);
		
		id1=Integer.parseInt(id);
		
		try 
		{
			object=service.getAsset(id1);
			System.out.println(object);
			request.getSession().setAttribute("asset",object);
			} 
		catch (UserException e) 
		{
			e.printStackTrace();
		}
			rd = request.getRequestDispatcher("confirm.jsp");
			rd.forward(request, response);
		break;
//***********************************************4) Modify.mvc method****************************************************************				
case "/Modify.mvc":
		System.out.println("modify");
		id=request.getParameter("id");
		
		id1=Integer.parseInt(id);
		
		String name=request.getParameter("name");
		String desc=request.getParameter("desc");
		String quantity=request.getParameter("quantity");
				
		object.setAssetid(id1);
		object.setAssetname(name);
		object.setAssetdes(desc);
		object.setQuantity(quantity);
				
		try 
		{
			service.update(object);
			List<Asset> asset=service.getStatus();
			request.getSession().setAttribute("emplist", asset);
		} 
		catch (UserException e) 
		{
			request.getSession().setAttribute("error", e.getMessage());
		}
			rd = request.getRequestDispatcher("Admin.jsp");
			rd.forward(request, response);
		break;
//***********************************************5) Approve.mvc method****************************************************************				
case"/Approve.mvc":
		object.setStatus("Approve");
		try 
		{
			service.status(object);
			List<Asset> asset=service.getStatus();
		} 
		catch (UserException e) 
		{
			request.getSession().setAttribute("error", e.getMessage());
		}
			rd = request.getRequestDispatcher("Admin.jsp");
			rd.forward(request, response);
		break;
//***********************************************6) Reject.mvc method ****************************************************************						
case"/Reject.mvc":
		object.setStatus("Reject");
		try 
		{
			service.status(object);
			List<Asset> asset=service.getStatus();
		} 
		catch (UserException e) 
		{
			request.getSession().setAttribute("error", e.getMessage());
		}
			rd = request.getRequestDispatcher("Admin.jsp");
			rd.forward(request, response);
		break;
//***********************************************7) status.mvc method ****************************************************************									
case "/status.mvc":
		try
		{
			List<Asset> asset=service.getAll();
			System.out.println(asset);
			request.getSession().setAttribute("assetlist", asset);	//add list into SESSION
		}
		catch(UserException ex)
		{
			request.getSession().setAttribute("error", ex.getMessage());
		}
			rd = request.getRequestDispatcher("status.jsp");
			rd.forward(request, response);
		break;
//***********************************************8) showModify.mvc****************************************************************									
case"/showModify.mvc":
		try
		{
			List<Asset> asset=service.showmodfy();
			request.getSession().setAttribute("assetlist", asset);
		}
		catch(UserException ex)
		{
			request.getSession().setAttribute("error", ex.getMessage());
		}
					
			rd = request.getRequestDispatcher("status.jsp");
			rd.forward(request, response);
		break;
//***********************************************9) showApprove.mvc****************************************************************										
case"/showApprove.mvc":
		try
		{
			List<Asset> asset=service.showapprove();
			request.getSession().setAttribute("assetlist", asset);
		}
		catch(UserException ex)
		{
			request.getSession().setAttribute("error", ex.getMessage());
		}
			rd = request.getRequestDispatcher("status.jsp");
			rd.forward(request, response);
		break;
//***********************************************10) showReject.mvc****************************************************************										
case"/showReject.mvc":
		try
		{
			List<Asset> asset=service.showreject();
			request.getSession().setAttribute("assetlist", asset);
		}
		catch(UserException ex)
		{
			request.getSession().setAttribute("error", ex.getMessage());
		}
			rd = request.getRequestDispatcher("status.jsp");
			rd.forward(request, response);
		break;
	}//Switch Case Ends Here
}//Doget Method Ends Here

protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{ 
	doGet(request,response); //Dopost Method calling calling Doget Method  
	}
}// Class Ends Here



