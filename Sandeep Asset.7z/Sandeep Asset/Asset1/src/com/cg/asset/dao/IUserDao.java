package com.cg.asset.dao;

import java.util.List;

import com.cg.asset.dto.Asset;
import com.cg.asset.dto.Employee;
import com.cg.asset.exception.UserException;

public interface IUserDao {
Integer compare(String userid,String password) throws UserException;
public int addasset(Asset ast);
List<Asset> getAll() throws UserException;
Asset getAsset(int id2) throws UserException;
void update(Asset object) throws UserException;
void status(Asset object) throws UserException;
List<Asset> getStatus() throws UserException;
List<Asset> showmodify() throws UserException;
List<Asset> showapprove() throws UserException;
List<Asset> showreject() throws UserException;
List<Employee> showAll() throws UserException;

}
