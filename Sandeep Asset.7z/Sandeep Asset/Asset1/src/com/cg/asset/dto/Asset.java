package com.cg.asset.dto;

public class Asset {
	
	private Integer assetid;
	private String assetname;
	private String assetdes;
	private String quantity;
	private String status;
	public Integer getAssetid() {
		return assetid;
	}
	public void setAssetid(Integer assetid) {
		this.assetid = assetid;
	}
	public String getAssetname() {
		return assetname;
	}
	public void setAssetname(String assetname) {
		this.assetname = assetname;
	}
	public String getAssetdes() {
		return assetdes;
	}
	public void setAssetdes(String assetdes) {
		this.assetdes = assetdes;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "Asset [assetid=" + assetid + ", assetname=" + assetname
				+ ", assetdes=" + assetdes + ", quantity=" + quantity
				+ ", status=" + status + "]";
	}
	public Asset(Integer assetid, String assetname, String assetdes,
			String quantity, String status) {
		super();
		this.assetid = assetid;
		this.assetname = assetname;
		this.assetdes = assetdes;
		this.quantity = quantity;
		this.status = status;
	}
	public Asset() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((assetdes == null) ? 0 : assetdes.hashCode());
		result = prime * result + ((assetid == null) ? 0 : assetid.hashCode());
		result = prime * result
				+ ((assetname == null) ? 0 : assetname.hashCode());
		result = prime * result
				+ ((quantity == null) ? 0 : quantity.hashCode());
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Asset other = (Asset) obj;
		if (assetdes == null) {
			if (other.assetdes != null)
				return false;
		} else if (!assetdes.equals(other.assetdes))
			return false;
		if (assetid == null) {
			if (other.assetid != null)
				return false;
		} else if (!assetid.equals(other.assetid))
			return false;
		if (assetname == null) {
			if (other.assetname != null)
				return false;
		} else if (!assetname.equals(other.assetname))
			return false;
		if (quantity == null) {
			if (other.quantity != null)
				return false;
		} else if (!quantity.equals(other.quantity))
			return false;
		if (status == null) {
			if (other.status != null)
				return false;
		} else if (!status.equals(other.status))
			return false;
		return true;
	}
	

	
}
