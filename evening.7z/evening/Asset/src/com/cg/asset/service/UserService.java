package com.cg.asset.service;

import java.util.List;

import com.cg.asset.dao.IUserDao;
import com.cg.asset.dao.UserDao;
import com.cg.asset.dto.Asset;
import com.cg.asset.dto.Employee;
import com.cg.asset.dto.User;
import com.cg.asset.exception.UserException;

public class UserService implements IUserService {
	IUserDao dao=new UserDao();

	@Override
	public Integer compare(String userid,String password) throws UserException {
		// TODO Auto-generated method stub
		return dao.compare(userid, password);
	}

	@Override
	public int add(Asset ast) {
		// TODO Auto-generated method stub
		return dao.addasset(ast);
	}

	@Override
	public List<Asset> getAll() throws UserException {
		
		return dao.getAll();
	}

	@Override
	public Asset getAsset(int id2) throws UserException {
		
		return dao.getAsset(id2);
	}

	@Override
	public void update(Asset object) throws UserException {
		dao.update(object);
		
	}

	@Override
	public void status(Asset object) throws UserException {
	dao.status(object);
		
	}

	@Override
	public List<Asset> getStatus() throws UserException {
		return dao.getStatus();
	}

	@Override
	public List<Asset> showmodfy() throws UserException {		
		return dao.showmodify();
	}

	@Override
	public List<Asset> showapprove() throws UserException {
		return dao.showapprove();
	}

	@Override
	public List<Asset> showreject() throws UserException {
		return dao.showreject();
	}

	@Override
	public List<Employee> showAll() throws UserException {
		return dao.showAll();
	}

	

	
}
