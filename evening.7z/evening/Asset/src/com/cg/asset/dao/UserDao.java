package com.cg.asset.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;

import javax.naming.NamingException;



import com.cg.asset.dto.Asset;
import com.cg.asset.dto.Employee;
import com.cg.asset.dto.User;
import com.cg.asset.exception.UserException;
import com.cg.asset.util.DbUtil;

public class UserDao  implements IUserDao {
	
	private static final String SHOW_ALL_QUERY="select * from Employee";
	
	private static final String INSERT_QUERY
	="INSERT into asset(assetid,assetname,assetdes,quantity,status) "+  
		"   values(?,?,?,?,?)";
	private static final String GET_QUERY="select userid,username,userpassword,usertype from user_master where userid=?";
	
	private static final String GET_ALL_QUERY ="select * from asset where status='pending'";
	private static final String SHOW_MODIFY ="select * from asset where status='Modify'";
	private static final String SHOW_APPROVE ="select * from asset where status='Approve'";
	private static final String SHOW_REJECT ="select * from asset where status='Reject'";
	
	private static final String GET_ALL_STATUS
	="select assetid,assetname,assetdes,quantity,status from asset where status!='Approve' AND status!='Reject'";
	
	private static final String UPDATE_QUERY="update asset set assetid=?,assetname=?,assetdes=?,quantity=?,status=? where assetid=?"
;
	
	Connection con = null;
	PreparedStatement ps = null;
	@Override
	public Integer compare(String userid,String password) throws UserException {
	    User user=null;
	    Connection conn=null;
	    PreparedStatement pst=null;
	    Integer compare = null;
	    try {
	         conn=DbUtil.getConnection();
	       String id=userid;
	        String pass=password;
	        pst=conn.prepareStatement("Select usertype from  user_master where userid = ? and userpassword = ? "); 
	   		    pst.setString(1,id); 
	   		    pst.setString(2,pass);
	   		  
	   		    ResultSet rst=pst.executeQuery(); 
	   		    while(rst.next()) 
	   		    { 
	   		    String type=rst.getString("usertype"); 
	   		   
	   		    System.out.println("user type="+type); 
	   		    if(type.equals("admin")) 
	   		    { 
	   		    	return 1;
	   		    } 
	   		    else if("manager".equals(type)) 
	   		    { 
	   		    return 2;
	   		    } 
	   	  
	        }

	    }   
	    catch(SQLException | NamingException e )
	    {
	    	throw new UserException();
	    }
	    finally
	    {
	        try{
	           pst.close();
	           
	            conn.close();
	        }
	        catch(SQLException e)
	        {
	            e.printStackTrace();
	        }
	    }
	
		return compare;
	}

	@Override
	public int addasset(Asset ast) {
		int id=0;
		try {
			con = DbUtil.getConnection();
			 ps = con.prepareStatement(INSERT_QUERY);
			 
			 id = getAssetid();
				ps.setInt(1,id);
				ps.setString(2,ast.getAssetname());
				ps.setString(3,ast.getAssetdes());
				ps.setString(4,ast.getQuantity());
				ps.setString(5,ast.getStatus());
				ps.executeUpdate();
				con.close();
				
			 } catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return id;
	}
		
	private int getAssetid() {
		// TODO Auto-generated method stub
		
		int id =0;
		
		try {
			Connection connn = DbUtil.getConnection();
			
			Statement st = connn.createStatement();
			ResultSet rs = st.executeQuery("select asset_seq.nextval from dual");
			if(rs.next()){				
				id = rs.getInt(1);
				System.out.println("SEQ value "+id);
			}
		} catch (NamingException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return id;
	
	}

	@Override
	public List<Asset> getAll() throws UserException {
		try{
			Connection con = DbUtil.getConnection();
			PreparedStatement ps = con.prepareStatement(GET_ALL_QUERY);
			ResultSet rs = ps.executeQuery();
			//Create EMPTY list
			List<Asset> emps = new LinkedList<>();
			//Get ONE record at a time
			while(rs.next()){
				Asset e = new Asset();
				//Store ALL values into Employee Object
				//"e" is now D.T.O.
				e.setAssetid(rs.getInt(1));
				e.setAssetname(rs.getString(2));
				e.setAssetdes(rs.getString(3));
				e.setQuantity(rs.getString(4));
				e.setStatus(rs.getString(5));
				
				//Add DTO into LIST
				emps.add(e);
			}
			con.close();
			//return LIST
			return emps;
		}catch(NamingException | SQLException ex){
			throw new UserException("Unable to fetch records, "+ex.getMessage());
		}
		
	}

	@Override
	public List<Asset> getStatus() throws UserException {
		try{
			Connection con = DbUtil.getConnection();
			PreparedStatement ps = con.prepareStatement(GET_ALL_STATUS);
			ResultSet rs = ps.executeQuery();
			//Create EMPTY list
			List<Asset> emps = new LinkedList<>();
			//Get ONE record at a time
			while(rs.next()){
				Asset e = new Asset();
				//Store ALL values into Employee Object
				//"e" is now D.T.O.
				e.setAssetid(rs.getInt(1));
				e.setAssetname(rs.getString(2));
				e.setAssetdes(rs.getString(3));
				e.setQuantity(rs.getString(4));
				e.setStatus(rs.getString(5));
				
				//Add DTO into LIST
				emps.add(e);
			}
			con.close();
			//return LIST
			return emps;
		}catch(NamingException | SQLException ex){
			throw new UserException("Unable to fetch records, "+ex.getMessage());
		}
		
	}
	@Override
	public Asset getAsset(int id2) throws UserException {

		Asset search=null;
		try {
			con = DbUtil.getConnection();
		
			String querythree="Select assetid,assetname,assetdes,quantity,status from asset where assetid=?";
					ps=con.prepareStatement(querythree);
					ps.setInt(1,id2);
					ResultSet restwo = ps.executeQuery();
					while(restwo.next())
					{
						search = new Asset();
						search.setAssetid(restwo.getInt(1));
						search.setAssetname(restwo.getString(2));
						search.setAssetdes(restwo.getString(4));
						search.setQuantity(restwo.getString(5));
					}	
		} 
		catch (SQLException | NamingException e) 
		{
			e.printStackTrace();
			throw new UserException("Problem in search..");
		}
		finally
		{
			try {
				ps.close();
				con.close();
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
			
		}
		return search;
	}

	@Override
	public void update(Asset object) throws UserException {
try {
			con=DbUtil.getConnection();
			 ps = con.prepareStatement(UPDATE_QUERY);
			 ps.setInt(1,object.getAssetid());
			 ps.setString(2,object.getAssetname());
			 ps.setString(3,object.getAssetdes());
			 ps.setString(4,object.getQuantity());
			 ps.setString(5, "Modify");
			 ps.setInt(6,object.getAssetid());
			 ps.executeUpdate();
				System.out.println("yahan aa gya");
				System.out.println(object);	
				con.close();
			 
		} catch (NamingException  | SQLException e1) {
			
			e1.printStackTrace();
			throw new UserException("Unable to save, "+e1.getMessage());
		} 
		
	}

	@Override
	public void status(Asset object) throws UserException {
		try {
			con=DbUtil.getConnection();
			 ps = con.prepareStatement("update asset set status=? where assetid=?");
			 ps.setString(1,object.getStatus());
			 ps.setInt(2,object.getAssetid());
			 ps.executeUpdate();
			 con.close();
			 
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new UserException("Unable to save, "+e.getMessage());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new UserException("Unable to save, "+e.getMessage());
		}
		
	}

	@Override
	public List<Asset> showmodify() throws UserException {
		try{
			Connection con = DbUtil.getConnection();
			PreparedStatement ps = con.prepareStatement(SHOW_MODIFY);
			ResultSet rs = ps.executeQuery();
			//Create EMPTY list
			List<Asset> emps = new LinkedList<>();
			//Get ONE record at a time
			while(rs.next()){
				Asset e = new Asset();
				//Store ALL values into Employee Object
				//"e" is now D.T.O.
				e.setAssetid(rs.getInt(1));
				e.setAssetname(rs.getString(2));
				e.setAssetdes(rs.getString(3));
				e.setQuantity(rs.getString(4));
				e.setStatus(rs.getString(5));
				
				//Add DTO into LIST
				emps.add(e);
			}
			con.close();
			//return LIST
			return emps;
		}catch(NamingException | SQLException ex){
			throw new UserException("Unable to fetch records, "+ex.getMessage());
		}
	}

	@Override
	public List<Asset> showapprove() throws UserException {
		try{
			Connection con = DbUtil.getConnection();
			PreparedStatement ps = con.prepareStatement(SHOW_APPROVE);
			ResultSet rs = ps.executeQuery();
			//Create EMPTY list
			List<Asset> emps = new LinkedList<>();
			//Get ONE record at a time
			while(rs.next()){
				Asset e = new Asset();
				//Store ALL values into Employee Object
				//"e" is now D.T.O.
				e.setAssetid(rs.getInt(1));
				e.setAssetname(rs.getString(2));
				e.setAssetdes(rs.getString(3));
				e.setQuantity(rs.getString(4));
				e.setStatus(rs.getString(5));
				
				//Add DTO into LIST
				emps.add(e);
			}
			con.close();
			//return LIST
			return emps;
		}catch(NamingException | SQLException ex){
			throw new UserException("Unable to fetch records, "+ex.getMessage());
		}
	}

	@Override
	public List<Asset> showreject() throws UserException {
		try{
			Connection con = DbUtil.getConnection();
			PreparedStatement ps = con.prepareStatement(SHOW_REJECT);
			ResultSet rs = ps.executeQuery();
			//Create EMPTY list
			List<Asset> emps = new LinkedList<>();
			//Get ONE record at a time
			while(rs.next()){
				Asset e = new Asset();
				//Store ALL values into Employee Object
				//"e" is now D.T.O.
				e.setAssetid(rs.getInt(1));
				e.setAssetname(rs.getString(2));
				e.setAssetdes(rs.getString(3));
				e.setQuantity(rs.getString(4));
				e.setStatus(rs.getString(5));
				
				//Add DTO into LIST
				emps.add(e);
			}
			con.close();
			//return LIST
			return emps;
		}catch(NamingException | SQLException ex){
			throw new UserException("Unable to fetch records, "+ex.getMessage());
		}
	}

	@Override
	public List<Employee> showAll() throws UserException {
		try{
			Connection con = DbUtil.getConnection();
			PreparedStatement ps = con.prepareStatement(SHOW_ALL_QUERY);
			ResultSet rs = ps.executeQuery();
			//Create EMPTY list
			List<Employee> emps = new LinkedList<>();
			//Get ONE record at a time
			while(rs.next()){
				Employee e=new Employee();
				e.setEmpNo(rs.getInt(1));
				e.setEmpName(rs.getString(2));
				e.setJob(rs.getString(3));
				e.setMgrNo(rs.getInt(4));
				e.setHiredate(rs.getDate(5));
				e.setDeptId(rs.getInt(6));
				
				//Add DTO into LIST
				emps.add(e);
			}
			con.close();
			//return LIST
			return emps;
		}catch(NamingException | SQLException ex){
			throw new UserException("Unable to fetch records, "+ex.getMessage());
		}
	} 
}
