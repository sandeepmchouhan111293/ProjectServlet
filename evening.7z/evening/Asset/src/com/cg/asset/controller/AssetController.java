package com.cg.asset.controller;

import java.io.IOException;




import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



import com.cg.asset.dto.Asset;
import com.cg.asset.dto.Employee;
import com.cg.asset.dto.User;
import com.cg.asset.exception.UserException;
import com.cg.asset.service.IUserService;
import com.cg.asset.service.UserService;
import com.cg.asset.util.DbUtil;




@WebServlet("*.mvc")
public class AssetController extends HttpServlet 
{
	  private static final long serialVersionUID = 1L;
IUserService service;
User user;
RequestDispatcher rd;
Asset object=new Asset();
@Override 
public void init() throws ServletException 
{ 
	service=new UserService();
}

protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
{ 
	String action=request.getServletPath();
System.out.println(action);
switch (action) {
//1) Form.mvc method
	case "/form.mvc":
			
			System.out.println("Started...!!!!!");
			   String id=request.getParameter("userid");
			   String pass=request.getParameter("password");
			   
			   try {
				int compare=service.compare(id,pass);
				System.out.println("compare" +compare);
				if(compare==1)
				{
					try{
						//code to list employees from service
						List<Asset> emps=service.getAll();
						//add list into SESSION
						request.getSession().setAttribute("emplist", emps);
						//forward request to "list.jsp"
						}catch(UserException ex){
							request.getSession().setAttribute("error", ex.getMessage());
						}
					
					   rd = request.getRequestDispatcher("Admin.jsp");
					    rd.forward(request, response);
				}
				else if(compare==2)
				{
					   rd = request.getRequestDispatcher("Manager.jsp");
					    rd.forward(request, response);
				}
			   } 
			   catch (UserException e) 
			   {
				e.printStackTrace();
			   }
			   break;		
//2) assetform.mvc method
		case "/assetform.mvc":
				System.out.println("assetform");
				
				object.setAssetname(request.getParameter("assetname"));
				object.setAssetdes(request.getParameter("assetdes"));
				object.setQuantity(request.getParameter("quantity"));
				object.setStatus("pending");
				 
							int id1=0;
					       try {
									id1=service.add(object);
									object.setAssetid(id1);
								} catch (Exception e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
										
					request.getSession().setAttribute("ast", object);
					
							rd = request.getRequestDispatcher("Manager.jsp");
							rd.forward(request, response);
							break;	
				
			case"/assetDetails.mvc":
				String id3=request.getParameter("id");
				System.out.println(id3);
						int id2=Integer.parseInt(id3);
					try {
						 object=service.getAsset(id2);
						System.out.println(object);
						request.getSession().setAttribute("asset",object);
					} catch (UserException e) {
						e.printStackTrace();
					}
			rd = request.getRequestDispatcher("confirm.jsp");
			rd.forward(request, response);
				break;
//3) Modify.mvc method 	modifying data
			case "/Modify.mvc":
				System.out.println("modify");
				String id4=request.getParameter("id");
				int id5=Integer.parseInt(id4);
				String name=request.getParameter("name");
				String desc=request.getParameter("desc");
				String quantity=request.getParameter("quantity");
				
				object.setAssetid(id5);
				object.setAssetname(name);
				object.setAssetdes(desc);
				object.setQuantity(quantity);
				
			try {
				service.update(object);
			} catch (UserException e) {
				e.printStackTrace();
			}
			try{
				List<Asset> asset=service.getStatus();
			}
			catch(UserException ex){
				request.getSession().setAttribute("error", ex.getMessage());
			}
			rd = request.getRequestDispatcher("Admin.jsp");
			rd.forward(request, response);
				break;
//4) Approve.mvc method  changing status 				
			case"/Approve.mvc":
				object.setStatus("Approve");
			try {
				service.status(object);
			} catch (UserException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			try{
				List<Asset> asset=service.getStatus();
			}
			catch(UserException ex){
				request.getSession().setAttribute("error", ex.getMessage());
			}
				rd = request.getRequestDispatcher("Admin.jsp");
				rd.forward(request, response);
				break;
//5) Reject.mvc method 
			case"/Reject.mvc":
				object.setStatus("Reject");
			try {
				service.status(object);
			} catch (UserException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try{
				List<Asset> asset=service.getStatus();
			}
			catch(UserException ex){
				request.getSession().setAttribute("error", ex.getMessage());
			}
				rd = request.getRequestDispatcher("Admin.jsp");
				rd.forward(request, response);
				break;
//6) status.mvc method 	fetching data to show after modification,approval or rejection		
			case "/status.mvc":
				try{
					//code to list employees from service
					List<Asset> asset=service.getAll();
					List<Employee> emp=service.showAll();
					System.out.println(asset);
					//add list into SESSION
					request.getSession().setAttribute("emplist", emp);
					request.getSession().setAttribute("assetlist", asset);
					//forward request to "list.jsp"
					}catch(UserException ex){
						request.getSession().setAttribute("error", ex.getMessage());
					}
				
				   rd = request.getRequestDispatcher("status.jsp");
				    rd.forward(request, response);
			break;
//7)showModify.mvc method to show modified requests
			case"/showModify.mvc":
					try{
						//code to list employees from service
						List<Asset> asset=service.showmodfy();
						//add list into SESSION
						request.getSession().setAttribute("assetlist", asset);
						//forward request to "list.jsp"
						}catch(UserException ex){
							request.getSession().setAttribute("error", ex.getMessage());
						}
					
					   rd = request.getRequestDispatcher("status.jsp");
					    rd.forward(request, response);
				break;
			case"/showApprove.mvc":
				try{
					//code to list employees from service
					List<Asset> asset=service.showapprove();
					//add list into SESSION
					request.getSession().setAttribute("assetlist", asset);
					//forward request to "list.jsp"
					}catch(UserException ex){
						request.getSession().setAttribute("error", ex.getMessage());
					}
				
				   rd = request.getRequestDispatcher("status.jsp");
				    rd.forward(request, response);
			break;
			case"/showReject.mvc":
				try{
					//code to list employees from service
					List<Asset> asset=service.showreject();
					//add list into SESSION
					request.getSession().setAttribute("assetlist", asset);
					//forward request to "list.jsp"
					}catch(UserException ex){
						request.getSession().setAttribute("error", ex.getMessage());
					}
				
				   rd = request.getRequestDispatcher("status.jsp");
				    rd.forward(request, response);
			break;
			}
		
}



protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException { 
	doGet(request,response); 
	}

}



